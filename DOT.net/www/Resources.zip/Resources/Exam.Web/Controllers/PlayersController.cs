﻿using Exam.DAL.Data;
using Exam.DAL.Models;
using Exam.Web.Helpers;
using Exam.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Exam.Web.Controllers
{
    public class PlayersController : Controller
    {
        private readonly ExamContext _context;

        public PlayersController(ExamContext context)
        {
            _context = context;
        }

        // GET: Players
        public async Task<IActionResult> Index()
        {
            return View(await _context.Players.Include(p => p.Country).ToListAsync());
        }

        // GET: Players/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var player = await _context.Players
                .FirstOrDefaultAsync(m => m.PlayerId == id);
            if (player == null)
            {
                return NotFound();
            }

            return View(player);
        }

        // GET: Players/Create
        public IActionResult Create()
        {
            var createPlayerViewModel = new CreateEditPlayerViewModel();
            createPlayerViewModel.Player = new Player();
            createPlayerViewModel.Countries = new SelectList(_context.Countries.ToList(), "CountryId", "Name");
            return View(createPlayerViewModel);
        }

        // POST: Players/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateEditPlayerViewModel createPlayerViewModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(createPlayerViewModel.Player);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            createPlayerViewModel.Countries = new SelectList(_context.Countries.ToList(), "CountryId", "Name");
            return View(createPlayerViewModel);
        }
        
        // Method to refactor AND unit test!
        public IActionResult Game(int playerid)
        {
            var gameViewModel = new GameViewModel();
            var opponent = _context.Players.Find(playerid);
            gameViewModel.Opponent = opponent;
            gameViewModel.ScoreOpponent = GameSimulator.GetRandomScore(opponent.Level);

            return View(gameViewModel);
        }

    }
}
