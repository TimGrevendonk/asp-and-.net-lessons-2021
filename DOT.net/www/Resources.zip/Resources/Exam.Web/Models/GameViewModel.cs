﻿using Exam.DAL.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Exam.Web.Models
{
    public class GameViewModel
    {
        public Player Opponent { get; set; }
        public int ScoreOpponent { get; set; }
    }
}
