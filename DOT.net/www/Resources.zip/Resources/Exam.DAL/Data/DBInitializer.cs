﻿using Exam.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.DAL.Data
{
    public class DBInitializer
    {
        public static void Initialize(ExamContext context)
        {
            context.Database.EnsureCreated();

            // Look for any players
            if (context.Players.Any())
            {
                return;   // DB has been seeded
            }

            // Add countries and players
            context.AddRange(
                new Country() { CountryId = 1, Name = "Wales" },
                new Country() { CountryId = 2, Name = "Schotland" },
                new Country() { CountryId = 3, Name = "Nederland" }
            );

            context.AddRange(
                new Player() { CountryId = 1, FirstName = "Gerwyn", LastName = "Price", BirthYear = 1985, Nickname = "The Iceman", TournamentsWon = 7, Level = 4 }, 
                new Player() { CountryId = 2, FirstName = "Peter", LastName = "Wright", BirthYear = 1970, Nickname = "Snakebite", TournamentsWon = 10, Level = 7 }, 
                new Player() { CountryId = 3, FirstName = "Michael", LastName = "van Gerwen", BirthYear = 1989, Nickname = "Mighty Mike", TournamentsWon = 0, Level = 10 },
                new Player() { CountryId = 2, FirstName = "Gary", LastName = "Anderson", BirthYear = 1970, Nickname = "Flying Scotsman", TournamentsWon = 7, Level = 2 }
            );

            context.SaveChanges();
        }
    }
}
