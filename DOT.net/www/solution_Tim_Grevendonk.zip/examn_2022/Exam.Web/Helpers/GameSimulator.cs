﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Exam.Web.Helpers
{
    public static class GameSimulator
    {
        public static int GetRandomScore(int level)
        {
            Random r = new Random();
            //Return a random score based on opponent's level (1 to 10)
            return r.Next(0, level * 18);
        }
    }
}
