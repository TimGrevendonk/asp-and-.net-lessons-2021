﻿using Exam.DAL.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Exam.Web.Models
{
    public class CreateEditPlayerViewModel
    {
        public Player Player { get; set; }
        public SelectList Countries { get; set; }
    }
}
