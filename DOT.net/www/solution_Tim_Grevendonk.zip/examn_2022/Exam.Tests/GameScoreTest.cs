using Microsoft.VisualStudio.TestTools.UnitTesting;
using Exam.Web.Helpers;
using Moq;
using Exam.DAL.Data;
using System.Collections;
using Exam.DAL.Repositories;
using Exam.Web.Controllers;
using Exam.DAL;
using Exam.Web.Models;
using Exam.DAL.Models;
using System.Collections.Generic;

namespace Exam.Tests
{
    [TestClass]
    public class GameScoreTest
    {
        [TestMethod]
        public void Get_Level4Score_RandomNumberBetween0And71()
        {
            // A list of numbers from 0 to 71(incl)
            ArrayList numbers = new ArrayList();
            for (int i = 0; i < 72; i++){
                numbers.Add(i);
            } 
            // Assert
            CollectionAssert.Contains(numbers, GameSimulator.GetRandomScore(4));
        }

        [TestMethod]
        public void Game_LevelSixOpponent_ReturnNUmberBetween0And108()
        {
            var contextMock = new Mock<ExamContext>();
            var UnitOfWorkMock = new UnitOfWork(contextMock.Object);

            var PlayerControllerMock = new Mock<PlayersController>(UnitOfWorkMock);

            var dartsplayer = new CreateEditPlayerViewModel
            {
                Player = new Player { PlayerId = 1111,
                    FirstName = "steven",
                    LastName = "universe",
                    BirthYear = 1995,
                    TournamentsWon = 3,
                    CountryId = 3,
                    Country = new Country { Name = "obasu" },
                    Level = 6
                }
            };

            //PlayerControllerMock.Create(dartsplayer);

            //PlayerControllerMock.Game(dartsplayer.Player.Level);

            PlayerControllerMock.Verify(r => r.Game(It.IsAny<int>()), Times.AtLeastOnce());

        }
    }
}
