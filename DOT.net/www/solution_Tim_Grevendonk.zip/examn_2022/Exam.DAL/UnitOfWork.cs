﻿using Exam.DAL.Data;
using Exam.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.DAL
{
    public class UnitOfWork : IUnitOfWork
    {
        private ExamContext _context;
        private PlayerRepository playerRepository;
        private CountryRepository countryRepository;

        public UnitOfWork(ExamContext context)
        {
            this._context = context;
        }

        public PlayerRepository PlayerRepository
        {
            get
            {
                if (this.playerRepository == null)
                {
                    this.playerRepository = new PlayerRepository(_context);
                }
                return this.playerRepository;
            }
        }

        public CountryRepository CountryRepository
        {
            get
            {
                if (this.countryRepository == null)
                {
                    this.countryRepository = new CountryRepository(_context);
                }
                return this.countryRepository;
            }
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}
