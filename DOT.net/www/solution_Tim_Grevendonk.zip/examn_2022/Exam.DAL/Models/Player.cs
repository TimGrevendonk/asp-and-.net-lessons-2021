﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.DAL.Models
{
    public class Player
    {
        public int PlayerId { get; set; }
        [Display(Name = "First name")]
        public string FirstName { get; set; }
        [Display(Name = "Last name")]
        public string LastName { get; set; }
        public string Nickname { get; set; }
        [Display(Name = "Birth year")]
        public int BirthYear { get; set; }
        [Display(Name = "# Tournament wins")]
        public int TournamentsWon { get; set; }
        [NotMapped]
        [Display(Name = "Name")]
        public string FullName
        {
            get
            {
                return $"{FirstName} {LastName}";
            }
        }

        public int CountryId { get; set; }
        public Country Country { get; set; }
        public int Level { get; set; }
    }
}
