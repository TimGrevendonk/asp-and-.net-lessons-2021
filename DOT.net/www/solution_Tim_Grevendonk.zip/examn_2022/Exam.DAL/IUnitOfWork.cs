﻿using Exam.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.DAL
{
    public interface IUnitOfWork
    {
        PlayerRepository PlayerRepository { get; }
        CountryRepository CountryRepository { get; }
        void SaveChanges();

        Task SaveChangesAsync();
    }
}
