﻿using Exam.DAL.Data;
using Exam.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.DAL.Repositories
{
    public class CountryRepository : GenericRepository<Country>
    {
        public CountryRepository(ExamContext context) : base(context)
        {

        }


    }
}
