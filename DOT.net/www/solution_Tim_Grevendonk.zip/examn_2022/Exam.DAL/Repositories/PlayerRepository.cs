﻿using Exam.DAL.Data;
using Exam.DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.DAL.Repositories
{
    public class PlayerRepository : GenericRepository<Player>
    {
        public PlayerRepository(ExamContext context) : base(context)
        {

        }

        public override IEnumerable<Player> All()
        {
            return _table
                .Include(c => c.Country)
                .ToList();
        }
        public override async Task<IEnumerable<Player>> AllAsync()
        {
            return await _table
                .Include(c => c.Country)
                .ToListAsync();
        }

        public override Player Add(Player entity)
        {
            entity.LastName = entity.LastName.ToUpper();
            return _table
                .Add(entity)
                .Entity;
        }

        public override Player Update(Player entity)
        {
            entity.LastName = entity.LastName.ToUpper();
            return _context.Update(entity)
                .Entity;
        }

    }
}
