﻿using Exam.DAL.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Exam.DAL.Repositories
{
    public abstract class GenericRepository<T>
            : IRepository<T> where T : class
    {
        protected ExamContext _context;
        protected DbSet<T> _table = null;

        public GenericRepository(ExamContext context)
        {
            _context = context;
            _table = _context.Set<T>();
        }

        public virtual T Add(T entity)
        {
            return _table
                .Add(entity)
                .Entity;
        }

        public virtual T Get(int id)
        {
            return _context.Find<T>(id);
        }

        public virtual async Task<T> GetAsync(int id)
        {
            return await _context.FindAsync<T>(id);
        }

        public virtual IEnumerable<T> All()
        {
            return _table
                .ToList();
        }

        public virtual async Task<IEnumerable<T>> AllAsync()
        {
            return await _table.ToListAsync();
        }

        public virtual IEnumerable<T> Find(Expression<Func<T, bool>> filter)
        {
            return _table.Where(filter)
                .ToList();
        }

        public virtual async Task<IEnumerable<T>> FindAsync(Expression<Func<T, bool>> filter)
        {
            return await _table.Where(filter)
                .ToListAsync();
        }

        public virtual T Update(T entity)
        {
            return _context.Update(entity)
                .Entity;
        }

        public virtual void Delete(T entity)
        {
            _context.Remove(entity);
        }

        public virtual int Total()
        {
            return _table.Count();
        }
    }
}
